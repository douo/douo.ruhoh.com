//
//  XFUtils.h
//  XFlags
//
//  Created by nark on 24/01/11.
//  Copyright 2011 OPALE. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface XFUtils : NSObject {

}

+ (BOOL)isFilesHidden;
+ (void)showHiddenFiles;
+ (void)hideHiddenFiles;

@end
